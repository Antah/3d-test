﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    [SerializeField]
    private MeshRenderer mr;
    [SerializeField]
    private SphereCollider sc;
    [SerializeField]
    private GameObject explosionObject;
    [SerializeField]
    private int damage;

    public void Init(float damageModifier)
    {
        damage = (int)((float)damage * damageModifier);
        Destroy(3.0f);
    }

    void OnCollisionEnter(Collision collisionInfo)
    {
        Destroy();
        if (collisionInfo.gameObject.tag == "Enemy")
            collisionInfo.gameObject.GetComponent<Enemy>().GetHit(damage);
    }

    private void Destroy(float time = 0f)
    {
        StartCoroutine(DestroyWithDelay(time));
    }

    IEnumerator DestroyWithDelay(float time)
    {
        yield return new WaitForSeconds(time);

        if (explosionObject != null)
        {
            GameObject explosion = Instantiate(explosionObject, new Vector3(transform.position.x, transform.position.y, transform.position.z), transform.rotation);
            explosion.transform.parent = transform.parent;
            explosion.SetActive(true);
        }
        mr.enabled = false;
        sc.enabled = false;
        yield return new WaitForSeconds(1f);
        Destroy(gameObject);
        transform.SetParent(null);
    }
}
