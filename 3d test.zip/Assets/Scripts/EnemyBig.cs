﻿using UnityEngine;

class EnemyBig : Enemy
{
}