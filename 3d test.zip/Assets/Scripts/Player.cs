﻿using UnityEngine;

class Player : Enemy
{
}

