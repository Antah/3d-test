﻿using System.Collections;
using UniRx;
using UnityEngine;

public class CharacterControls : MonoBehaviour
{
    public Transform bulletsParent;
    public Transform bulletStart;
    public GameObject bullet;
    public GameObject bullet2;
    public Rigidbody rb;
    public float speed = 10.0f;
    public float gravity = 10.0f;
    public float maxVelocityChange = 10.0f;
    public bool canJump = true;
    public float jumpHeight = 2.0f;
    public bool grounded = false;

    public float shootDelayGun = 0.2f, shootDelayBomb = 1f;
    public ReactiveProperty<float> elapsedGun, elapsedBomb;

    public ReactiveProperty<float> gunBoostTimer, speedBoostTimer;

    public float damageModifier = 1f;
    public float speedModifier = 1f;

    void Awake()
    {
        Cursor.visible = false;
        rb = GetComponent<Rigidbody>();
        elapsedGun = new ReactiveProperty<float>(0f);
        elapsedBomb = new ReactiveProperty<float>(0f);
        gunBoostTimer = new ReactiveProperty<float>(0f);
        speedBoostTimer = new ReactiveProperty<float>(0f);

        speedBoostTimer.Where(x => x > 0f).Subscribe(_ => { speedModifier = 1.5f; });
        gunBoostTimer.Where(x => x > 0f).Subscribe(_ => { damageModifier = 1.5f; });
        speedBoostTimer.Where(x => x <= 0f).Subscribe(_ => { speedModifier = 1f; });
        gunBoostTimer.Where(x => x <= 0f).Subscribe(_ => { damageModifier = 1f; });
    }

    void ShootGun()
    {
        GameObject BulletClone = Instantiate(bullet, new Vector3(bulletStart.position.x, bulletStart.position.y, bulletStart.position.z), transform.rotation);
        BulletClone.transform.parent = bulletsParent;
        BulletClone.SetActive(true);
        BulletClone.GetComponent<Bullet>().Init(damageModifier);
        BulletClone.GetComponent<Rigidbody>().AddForce(transform.forward * 100);
    }

    void ShootBomb()
    {
        GameObject BulletClone = Instantiate(bullet2, new Vector3(bulletStart.position.x, bulletStart.position.y, bulletStart.position.z), transform.rotation);
        BulletClone.transform.parent = bulletsParent;
        BulletClone.SetActive(true);
        BulletClone.GetComponent<Bullet>().Init(damageModifier);
        BulletClone.GetComponent<Rigidbody>().AddForce(transform.forward * 80);
        BulletClone.GetComponent<Rigidbody>().AddForce(transform.up * 40);
    }

    void FixedUpdate()
    {
        float mouseInputX = Input.GetAxis("Mouse X");
        float mouseInputY = Input.GetAxis("Mouse Y");
        Vector3 lookhere = new Vector3(0, mouseInputX * 10, 0);
        transform.Rotate(lookhere);

        elapsedGun.Value += Time.deltaTime;
        if (Input.GetMouseButton(0) && elapsedGun.Value >= shootDelayGun)
        {
            elapsedGun.Value = 0f;
            ShootGun();
        }
        elapsedBomb.Value += Time.deltaTime;
        if (Input.GetMouseButtonDown(1) && elapsedBomb.Value >= shootDelayBomb)
        {
            elapsedBomb.Value = 0f;
            ShootBomb();
        }


        if (grounded)
        {
            // Calculate how fast we should be moving
            Vector3 targetVelocity = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
            targetVelocity = transform.TransformDirection(targetVelocity);
            targetVelocity *= speed * speedModifier;

            // Apply a force that attempts to reach our target velocity
            Vector3 velocity = rb.velocity;
            Vector3 velocityChange = (targetVelocity - velocity);
            velocityChange.x = Mathf.Clamp(velocityChange.x, -maxVelocityChange, maxVelocityChange);
            velocityChange.z = Mathf.Clamp(velocityChange.z, -maxVelocityChange, maxVelocityChange);
            velocityChange.y = 0;
            rb.AddForce(velocityChange, ForceMode.VelocityChange);

            // Jump
            if (canJump && Input.GetButton("Jump"))
            {
                rb.velocity = new Vector3(velocity.x, CalculateJumpVerticalSpeed(), velocity.z);
                this.gameObject.layer = 10;
            }
        }

        // We apply gravity manually for more tuning control
        rb.AddForce(new Vector3(0, -gravity * rb.mass, 0));

        grounded = false;
    }

    void OnCollisionStay()
    {
        grounded = true;
        this.gameObject.layer = 9;
    }

    float CalculateJumpVerticalSpeed()
    {
        // From the jump height and gravity we deduce the upwards speed 
        // for the character to reach at the apex.
        return Mathf.Sqrt(2 * jumpHeight * speedModifier * gravity);
    }

    public void SpeedBoost()
    {
        speedBoostTimer.Value += 10f;
    }

    public void GunBoost()
    {
        gunBoostTimer.Value += 10f;
    }

    private void Update()
    {
        if (speedBoostTimer.Value > 0f)
            speedBoostTimer.Value -= Time.deltaTime;
        if (gunBoostTimer.Value > 0f)
            gunBoostTimer.Value -= Time.deltaTime;
    }
}