﻿using UnityEngine;

class EnemySmall : Enemy
{
}